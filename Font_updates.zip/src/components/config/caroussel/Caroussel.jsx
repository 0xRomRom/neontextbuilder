import stl from "./Caroussel.module.css";

const Caroussel = () => {
  return <div className={stl.caroussel}></div>;
};

export default Caroussel;
